import { forwardRef } from "react"

const Button = forwardRef(function Button({ text, className, handleClick, type }, ref) {
    return (
        <button
            ref={ref}
            onClick={handleClick}
            className={className}
            type={type}
        >
            {text}
        </button>
    )
})

export default Button